# Text Classification SDK

A Python SDK for training and using text classification models with user-defined labels.

## Installation

```bash
git clone https://github.com/iyke0z/text_classification_sdk.git
cd text_classification_sdk
pip install .
